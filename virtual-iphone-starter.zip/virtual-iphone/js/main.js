const $ = (s) => document.querySelector(s);
const lockScreen = $("#lockScreen"), passcodeScreen = $("#passcodeScreen");
const homeScreen = $("#homeScreen"), appView = $("#appView");
const lockWallpaper = $(".lock-wallpaper"), homeWallpaper = $(".home-wallpaper");
let entered = "";
const PASSCODE = "0922";
let notes = JSON.parse(localStorage.getItem("vi_notes") || "null") || [
  {id: 1, title: "hello, migo", body: "", updated: Date.now()}
];
let activeNoteId = null;
let songs = [
  ["Mahika","Adie & Janine Berdin"],
  ["An Art Gallery Could Never Be as Unique as You","mrld"],
  ["U + Me = <3","Olivia Rodrigo"],
  ["Afterglow","Taylor Swift"],
  ["Tsunami","NIKI"],
  ["Glue Song","beabadoobee"],
  ["Ikot","Over October"],
  ["Pasilyo","Sunkissed Lola"],
  ["Take A Chance With Me","NIKI"],
  ["Daylight","Taylor Swift"],
  ["It's Not Living (If It's Not With You)","The 1975"]
];
let currentSong = 0, isPlaying = false;
let photoDB;

function saveNotes(){ localStorage.setItem("vi_notes", JSON.stringify(notes)); }
function showOnly(view){
  [lockScreen,passcodeScreen,homeScreen,appView].forEach(v=>v.classList.add("hidden"));
  view.classList.remove("hidden");
}
function updateClock(){
  const now = new Date();
  const time = now.toLocaleTimeString([], {hour:"2-digit",minute:"2-digit",hour12:false});
  $("#lockClock").textContent = time;
  $("#homeTime").textContent = time;
  $("#lockDate").textContent = now.toLocaleDateString([], {weekday:"short",day:"numeric",month:"short"}).toUpperCase();
}
setInterval(updateClock,1000); updateClock();

function openPasscode(){ entered=""; updateDots(); $("#passcodeMessage").textContent=""; showOnly(passcodeScreen); }
function updateDots(){ [...$("#passcodeDots").children].forEach((d,i)=>d.classList.toggle("filled",i<entered.length)); }
function pressKey(key){
  if(key==="delete"){entered=entered.slice(0,-1);updateDots();return;}
  if(entered.length>=4)return;
  entered+=key;updateDots();
  if(entered.length===4){
    if(entered===PASSCODE){
      setTimeout(()=>{showOnly(homeScreen);lockWallpaper.style.opacity="0";homeWallpaper.style.opacity="1";},180);
    }else{
      $("#passcodeMessage").textContent="Incorrect passcode. Try again.";
      setTimeout(()=>{entered="";updateDots();},650);
    }
  }
}
$("#lockSwipe").addEventListener("click",openPasscode);
$("#lockScreen").addEventListener("click",(e)=>{if(e.target.id!=="flashlight"&&e.target.id!=="cameraShortcut")openPasscode();});
$("#keypad").addEventListener("click",e=>{const b=e.target.closest("button[data-key]");if(b)pressKey(b.dataset.key);});
$("#deleteKey").addEventListener("click",()=>pressKey("delete"));
$("#cancelUnlock").addEventListener("click",()=>showOnly(lockScreen));
$("#flashlight").addEventListener("click",e=>{e.currentTarget.style.background="#fff9";setTimeout(()=>e.currentTarget.style.background="",250);});
$("#cameraShortcut").addEventListener("click",()=>openApp("camera"));
$("#homeIndicator").addEventListener("click",()=>showOnly(homeScreen));
$("#backHome").addEventListener("click",()=>showOnly(homeScreen));
$("#appHomeLine").addEventListener("click",()=>showOnly(homeScreen));

document.querySelectorAll("[data-app]").forEach(b=>b.addEventListener("click",()=>openApp(b.dataset.app)));
function openApp(name){
  const titles={notes:"Notes",photos:"Photos",spotify:"Spotify",instagram:"Instagram",phone:"Phone",messages:"Messages",netflix:"Netflix",letterboxd:"Letterboxd",codm:"Call of Duty: Mobile",mlbb:"Mobile Legends",roblox:"Roblox",reminders:"Reminders",calendar:"Calendar",clock:"Clock",camera:"Camera"};
  $("#appTitle").textContent=titles[name]||"App";
  const content=$("#appContent"); content.innerHTML="";
  if(name==="notes")renderNotes(content);
  else if(name==="photos")renderPhotos(content);
  else if(name==="spotify")renderSpotify(content);
  else renderPlaceholder(content,name,titles[name]||"App");
  showOnly(appView);
}
function renderNotes(root){
  const top=document.createElement("div");top.className="photo-toolbar";
  top.innerHTML="<span>On My iPhone</span><button class='primary-action' id='newNote'>＋ New Note</button>";root.append(top);
  const list=document.createElement("div");list.className="note-list";root.append(list);
  function refresh(){
    list.innerHTML="";
    notes.sort((a,b)=>b.updated-a.updated).forEach(n=>{
      const row=document.createElement("button");row.className="note-row";
      const title=document.createElement("strong");title.textContent=n.title||"New Note";
      const preview=document.createElement("small");preview.textContent=(n.body||"No additional text").slice(0,90);
      const date=document.createElement("small");date.textContent=new Date(n.updated).toLocaleDateString();
      row.append(title,preview,date);row.addEventListener("click",()=>editNote(n.id));list.append(row);
    });
  }
  $("#newNote").onclick=()=>{const n={id:Date.now(),title:"",body:"",updated:Date.now()};notes.push(n);saveNotes();editNote(n.id);};
  refresh();
}
function editNote(id){
  const n=notes.find(x=>x.id===id);if(!n)return;activeNoteId=id;
  const root=$("#appContent");root.innerHTML="";
  const actions=document.createElement("div");actions.className="photo-toolbar";
  actions.innerHTML="<button id='notesBack'>‹ Notes</button><button id='deleteNote' style='color:#d33;background:transparent'>Delete</button>";
  const title=document.createElement("input");title.className="note-title";title.placeholder="Title";title.value=n.title;
  const body=document.createElement("textarea");body.className="note-editor";body.placeholder="Start writing…";body.value=n.body;
  root.append(actions,title,body);
  $("#notesBack").onclick=()=>openApp("notes");
  $("#deleteNote").onclick=()=>{notes=notes.filter(x=>x.id!==id);saveNotes();openApp("notes");};
  const persist=()=>{n.title=title.value;n.body=body.value;n.updated=Date.now();saveNotes();};
  title.addEventListener("input",persist);body.addEventListener("input",persist);
  title.focus();
}
function openPhotoDB(){
  return new Promise((resolve,reject)=>{
    const req=indexedDB.open("virtualIphonePhotos",1);
    req.onupgradeneeded=()=>req.result.createObjectStore("photos",{keyPath:"id",autoIncrement:true});
    req.onsuccess=()=>{photoDB=req.result;resolve(photoDB);};req.onerror=()=>reject(req.error);
  });
}
async function renderPhotos(root){
  root.innerHTML="<div class='photo-toolbar'><strong>Library</strong><label class='primary-action' for='photoPicker'>＋ Add Photos</label><input id='photoPicker' type='file' accept='image/*' multiple hidden></div><div class='photo-grid' id='photoGrid'></div>";
  const grid=$("#photoGrid");
  try{
    const db=photoDB||await openPhotoDB();
    const tx=db.transaction("photos","readonly"),req=tx.objectStore("photos").getAll();
    req.onsuccess=()=>{
      const items=req.result;
      if(!items.length){grid.innerHTML="<div class='empty-state' style='grid-column:1/-1'>Your photos will appear here.<br><br>Tap Add Photos to import pictures from this device.</div>";return;}
      items.forEach(item=>{
        const img=document.createElement("img");img.src=URL.createObjectURL(item.blob);img.alt="Your photo";
        img.addEventListener("click",()=>showPhoto(img.src));grid.append(img);
      });
    };
  }catch(e){grid.innerHTML="<p class='empty-state'>Photo storage isn't available in this browser.</p>";}
  $("#photoPicker").addEventListener("change",async e=>{
    const db=photoDB||await openPhotoDB();const tx=db.transaction("photos","readwrite");
    [...e.target.files].forEach(file=>{if(file.type.startsWith("image/"))tx.objectStore("photos").add({blob:file,name:file.name,added:Date.now()});});
    tx.oncomplete=()=>renderPhotos(root);
  });
}
function showPhoto(src){
  const v=document.createElement("div");v.className="photo-viewer";v.innerHTML="<button aria-label='Close'>✕</button><img alt='Selected photo'>";
  v.querySelector("img").src=src;v.querySelector("button").onclick=()=>v.remove();v.addEventListener("click",e=>{if(e.target===v)v.remove();});document.body.append(v);
}
function renderSpotify(root){
  root.innerHTML="<div class='spotify-screen'><div class='spotify-top'><img class='spotify-cover' src='assets/covers/moon-purple.jpg' alt='Purple moon playlist cover'><div class='spotify-meta'><small>PLAYLIST</small><h2>🌙</h2><small>11 songs · Made for you</small></div></div><p style='color:#c8c0d4;font-size:12px;margin:22px 0'>A little collection of songs.</p><div id='songList'></div><div class='playbar'><span id='nowPlaying'>"+songs[0][0]+"</span><button id='prevSong'>◀</button><button id='togglePlay'>▶</button><button id='nextSong'>▶|</button></div></div>";
  const list=$("#songList");
  songs.forEach((s,i)=>{
    const row=document.createElement("div");row.className="song-row";
    const num=document.createElement("span");num.textContent=String(i+1).padStart(2,"0");num.style.color="#aaa";
    const b=document.createElement("button");const strong=document.createElement("strong");strong.textContent=s[0];const small=document.createElement("small");small.textContent=s[1];b.append(strong,small);b.onclick=()=>{currentSong=i;isPlaying=true;updatePlayer();};
    row.append(num,b);list.append(row);
  });
  $("#togglePlay").onclick=()=>{isPlaying=!isPlaying;updatePlayer();};
  $("#prevSong").onclick=()=>{currentSong=(currentSong+songs.length-1)%songs.length;isPlaying=true;updatePlayer();};
  $("#nextSong").onclick=()=>{currentSong=(currentSong+1)%songs.length;isPlaying=true;updatePlayer();};
  function updatePlayer(){$("#nowPlaying").textContent=songs[currentSong][0];$("#togglePlay").textContent=isPlaying?"Ⅱ":"▶";}
}
function renderPlaceholder(root,name,title){
  const icons={instagram:"◎",phone:"☎",messages:"●",netflix:"N",letterboxd:"▣",codm:"COD",mlbb:"ML",roblox:"◇",reminders:"✓",calendar:"6",clock:"◷",camera:"◉"};
  root.innerHTML="<div class='placeholder-app'><div class='big-icon'>"+(icons[name]||"✦")+"</div><h2>"+title+"</h2><p>This app is part of your virtual iPhone. We'll build its features in a later step.</p></div>";
}
