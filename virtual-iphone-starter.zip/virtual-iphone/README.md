# Virtual iPhone

A responsive browser-based iPhone-inspired simulator.

## Included in this starter
- Lock screen using your cat wallpaper
- Passcode screen (`0922`)
- Home screen using your moon wallpaper
- Notes app with a preloaded `hello, migo` note and browser saving
- Photos app with multi-image import and IndexedDB storage
- Spotify-style playlist `🌙` with your 11 selected tracks and a purple cover
- Display placeholders for Instagram, Phone, Messages, Netflix, Letterboxd, CODM, MLBB and Roblox

## Run locally
Open `index.html` in a browser. For best results, use a local static server or GitHub Pages because IndexedDB and some browser features can behave differently on `file://` pages.

## Publish with GitHub Pages
1. Create a GitHub repository.
2. Upload the contents of this folder (not the enclosing ZIP).
3. In the repository, open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. Open the published Pages URL.

## Notes about storage
Notes use localStorage. Imported photos use IndexedDB. Both are stored in the browser on the device where they were added; they do not automatically sync between devices.

## Next build steps
Implement richer app screens, simulated Instagram/messages/calls, settings, Control Center, swipe gestures, notifications, and further iOS-like transitions.
